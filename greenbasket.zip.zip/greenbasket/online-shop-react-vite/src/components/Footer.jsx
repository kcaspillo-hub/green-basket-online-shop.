export default function Footer() {
  return (
    <footer className="site-footer mt-5">
      <div className="container py-4 d-flex flex-column flex-md-row justify-content-between gap-2">
        <p className="mb-0">© {new Date().getFullYear()} Green Basket. All rights reserved.</p>
        <p className="mb-0">Small choices, greener living.</p>
      </div>
    </footer>
  );
}