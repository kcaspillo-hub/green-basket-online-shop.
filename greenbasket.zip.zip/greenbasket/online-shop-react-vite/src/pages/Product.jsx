import { Link, useParams } from "react-router-dom";
import { products } from "../data/products";

export default function Product() {
  const { id } = useParams();
  const product = products.find(item => item.id === Number(id));

  if (!product) {
    return <main className="container page-section"><h1>Product not found</h1><Link to="/shop">Return to Shop</Link></main>;
  }

  return (
    <main className="container page-section">
      <Link to="/shop" className="back-link">← Back to Shop</Link>
      <div className="row g-5 align-items-center mt-2">
        <div className="col-md-6"><img src={product.image} alt={product.name} className="detail-image" /></div>
        <div className="col-md-6">
          <p className="eyebrow">{product.category}</p>
          <h1 className="section-title">{product.name}</h1>
          <p className="price fs-3">₱{product.price.toFixed(2)}</p>
          <p className="text-secondary">{product.description}</p>
          <button className="btn btn-success btn-lg mt-2" type="button" onClick={() => window.alert("This is a layout-only demo. Cart functionality is not connected yet.")}>Add to Cart</button>
          <p className="small text-secondary mt-3">Demo button for layout purposes.</p>
        </div>
      </div>
    </main>
  );
}