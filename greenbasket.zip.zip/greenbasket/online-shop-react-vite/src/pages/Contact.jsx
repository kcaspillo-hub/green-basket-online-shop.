import { useState } from "react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    setSubmitted(true);
  }

  return (
    <main className="container page-section">
      <div className="row g-5">
        <div className="col-lg-5">
          <p className="eyebrow mb-1">WE WOULD LOVE TO HEAR FROM YOU</p>
          <h1 className="section-title">Contact Us</h1>
          <p className="text-secondary">Have a question about a product? Send our team a message.</p>
          <div className="contact-info mt-4">
            <p><strong>Email:</strong> greenbasket@example.com</p>
            <p><strong>Phone:</strong> 09665719769</p>
            <p><strong>Location:</strong> Iloilo City, Philippines</p>
          </div>
          <small className="text-secondary">The contact details above are sample information. Replace them with your group's approved details.</small>
        </div>
        <div className="col-lg-7">
          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="mb-3"><label className="form-label" htmlFor="name">Full Name</label><input className="form-control" id="name" name="name" required /></div>
            <div className="mb-3"><label className="form-label" htmlFor="email">Email Address</label><input className="form-control" id="email" name="email" type="email" required /></div>
            <div className="mb-3"><label className="form-label" htmlFor="message">Message</label><textarea className="form-control" id="message" name="message" rows="5" required /></div>
            <button className="btn btn-success" type="submit">Send Message</button>
            {submitted && <p className="alert alert-success mt-3 mb-0" role="status">Thank you! This demo form has received your message on this page.</p>}
          </form>
        </div>
      </div>
    </main>
  );
}