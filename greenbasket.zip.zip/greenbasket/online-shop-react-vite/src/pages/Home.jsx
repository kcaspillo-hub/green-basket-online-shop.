import { Link } from "react-router-dom";
import { products } from "../data/products";
import ProductCard from "../components/ProductCard";

export default function Home() {
  return (
    <>
      <section className="hero-section">
        <div className="container">
          <div className="row align-items-center min-vh-hero">
            <div className="col-lg-6 py-5">
              <p className="eyebrow">THOUGHTFUL FINDS FOR EVERYDAY LIFE</p>
              <h1>Make everyday living a little <span>greener.</span></h1>
              <p className="hero-copy">Discover useful, simple, and feel-good essentials selected to make your daily routine brighter.</p>
              <Link to="/shop" className="btn btn-success btn-lg mt-2">Shop Now <span aria-hidden="true">→</span></Link>
            </div>
            <div className="col-lg-6 py-4">
              <img className="hero-image" src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1200&q=85" alt="Green plants and sustainable everyday items" />
            </div>
          </div>
        </div>
      </section>
      <section className="container py-5">
        <div className="d-flex flex-wrap justify-content-between align-items-end mb-4 gap-2">
          <div><p className="eyebrow mb-1">HANDPICKED FOR YOU</p><h2 className="section-title mb-0">Featured products</h2></div>
          <Link to="/shop" className="text-success fw-semibold">View all products →</Link>
        </div>
        <div className="row g-4">
          {products.slice(0, 3).map(product => <ProductCard key={product.id} product={product} />)}
        </div>
      </section>
      <section className="why-section py-5">
        <div className="container text-center">
          <p className="eyebrow">OUR PROMISE</p>
          <h2 className="section-title">Useful things. Thoughtful choices.</h2>
          <p className="mx-auto why-copy">Green Basket brings together everyday products that are practical, welcoming, and easy to enjoy.</p>
        </div>
      </section>
    </>
  );
}